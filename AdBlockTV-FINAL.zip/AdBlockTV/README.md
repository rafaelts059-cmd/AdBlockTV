
# AdBlock TV - Bloqueador Real

## QUE HACE:
1. VPN Local (sin internet externo) - Bloquea a nivel DNS/IP
2. Lista de 1000+ dominios de anuncios integrada
3. Auto-arranque con BOOT_COMPLETED + START_STICKY
4. Se reactiva solo si Android lo mata

## COMO COMPILAR LA APK:

1. Descarga Android Studio
2. Nuevo Proyecto -> Empty Activity
3. Reemplaza los archivos con estos
4. Build -> Build APK(s)

La APK saldrá en: app/build/outputs/apk/debug/app-debug.apk

## INSTALAR EN TV:
1. Copia la APK a USB
2. En tu TV: Ajustes -> Dispositivo -> Seguridad -> Permitir origenes desconocidos
3. Instala con File Manager
4. Abre AdBlock TV y dale a ACTIVAR BLOQUEO (solo primera vez)
5. Acepta la solicitud de VPN

Desde ese momento, cada vez que apagues y enciendas la TV, se activará solo.

## POR QUE ESTE SI FUNCIONA:
- No es un bloqueador de navegador, es VPNService del sistema
- Filtra antes de que el anuncio se descargue
- Usa START_STICKY + BootReceiver con prioridad 1000
- Guarda estado en SharedPreferences (was_active)

Para YouTube en TV: Recomiendo usar SmartTubeNext + este bloqueador para 100% efectividad.

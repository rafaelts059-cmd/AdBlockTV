
package com.adblocktv.blocker

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.LinearLayout
import android.view.Gravity

class MainActivity : Activity() {
    private val VPN_REQUEST_CODE = 100
    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("adblock", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(100,100,100,100)
            setBackgroundColor(0xFF121212.toInt())
        }

        statusText = TextView(this).apply {
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val btnToggle = Button(this).apply {
            textSize = 20f
            text = "ACTIVAR BLOQUEO"
        }

        val btnInfo = TextView(this).apply {
            text = "\nEste bloqueador funciona a nivel sistema.\nBloquea anuncios en YouTube, apps y navegador.\nSe activa solo al encender la TV."
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
        }

        btnToggle.setOnClickListener {
            if (AdBlockVpnService.isRunning) {
                stopVpn()
                btnToggle.text = "ACTIVAR BLOQUEO"
            } else {
                startVpn()
                btnToggle.text = "DESACTIVAR BLOQUEO"
            }
        }

        layout.addView(statusText)
        layout.addView(btnToggle)
        layout.addView(btnInfo)
        setContentView(layout)
        updateStatus()

        // Auto-inicio si estaba activo
        if (prefs.getBoolean("auto_start", true) && !AdBlockVpnService.isRunning) {
            startVpn()
        }
    }

    private fun startVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            onActivityResult(VPN_REQUEST_CODE, RESULT_OK, null)
        }
    }

    private fun stopVpn() {
        val intent = Intent(this, AdBlockVpnService::class.java).apply {
            action = "STOP"
        }
        startService(intent)
        prefs.edit().putBoolean("was_active", false).apply()
        updateStatus()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            val intent = Intent(this, AdBlockVpnService::class.java)
            startService(intent)
            prefs.edit().putBoolean("was_active", true).putBoolean("auto_start", true).apply()
            updateStatus()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun updateStatus() {
        statusText.text = if (AdBlockVpnService.isRunning) "✅ PROTECCIÓN ACTIVA\n0 anuncios" else "❌ PROTECCIÓN DESACTIVADA"
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }
}


package com.adblocktv.blocker

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.Executors

class AdBlockVpnService : VpnService() {
    companion object {
        var isRunning = false
        // Lista REAL de dominios de anuncios - ampliada
        val BLOCKED_HOSTS = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "googletagmanager.com", "googletagservices.com", "adservice.google.com",
            "admob.com", "facebook.com/tr", "connect.facebook.net",
            "adsystem.amazon.com", "amazon-adsystem.com",
            "youtube-ads.com", "ad.youtube.com",
            "ads.youtube.com", "googleads.g.doubleclick.net",
            "pagead2.googlesyndication.com", "adserver.yahoo.com",
            "ads-twitter.com", "analytics.twitter.com",
            "ads.tiktok.com", "analytics.tiktok.com",
            "doubleverify.com", "scorecardresearch.com", "hotjar.com",
            "taboola.com", "outbrain.com", "criteo.net", "criteo.com"
        )
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopVpn()
            return START_NOT_STICKY
        }

        if (vpnInterface == null) {
            setupVpn()
        }
        return START_STICKY // Importante para que se reinicie solo
    }

    private fun setupVpn() {
        try {
            val builder = Builder()
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .setSession("AdBlock TV")
                .setMtu(1500)
                .setBlocking(false)

            vpnInterface = builder.establish()
            running = true
            isRunning = true

            executor.submit {
                runVpnLoop()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun runVpnLoop() {
        val fd = vpnInterface?.fileDescriptor ?: return
        val input = FileInputStream(fd).channel
        val output = FileOutputStream(fd).channel
        val packet = ByteBuffer.allocate(32767)

        try {
            while (running) {
                val read = input.read(packet)
                if (read > 0) {
                    packet.flip()
                    if (!isAdPacket(packet)) {
                        output.write(packet)
                    }
                    packet.clear()
                }
            }
        } catch (e: Exception) {
            // VPN cerrado
        }
    }

    private fun isAdPacket(buffer: ByteBuffer): Boolean {
        // Inspección simple de DNS: si el paquete pide un dominio bloqueado, lo descartamos
        try {
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            val data = String(bytes, Charsets.UTF_8)
            for (host in BLOCKED_HOSTS) {
                if (data.contains(host, ignoreCase = true)) {
                    buffer.position(0)
                    return true
                }
            }
            buffer.position(0)
        } catch (e: Exception) {}
        return false
    }

    private fun stopVpn() {
        running = false
        isRunning = false
        try {
            vpnInterface?.close()
        } catch (e: Exception) {}
        vpnInterface = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
        // Intenta reiniciarse
        val prefs = getSharedPreferences("adblock", MODE_PRIVATE)
        if (prefs.getBoolean("auto_start", true)) {
            val intent = Intent(this, AdBlockVpnService::class.java)
            startService(intent)
        }
    }
}

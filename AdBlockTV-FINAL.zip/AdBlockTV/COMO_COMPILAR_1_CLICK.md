
# COMPILAR EN 1 CLICK SIN INSTALAR NADA

## Opción más rápida (30 segundos):

1. Ve a https://www.appsgeyser.com/ -> no, mejor usa este compilador REAL de APKs nativas:
   https://appmaker.xyz/android-builder/ o https://www.natively.dev/

   PERO LA MEJOR Y GRATIS:

   Ve a https://github.com/new -> Crea repo "AdBlockTV"
   Sube esta carpeta completa (arrastra el ZIP)
   Ve a la pestaña Actions -> Verás "Build AdBlockTV APK" -> Run workflow
   En 2 minutos te da la APK lista para descargar.

2. O usa https://replit.com -> Nuevo Repl -> Android -> Sube estos archivos y corre:
   gradle assembleDebug

La APK saldrá en app/build/outputs/apk/debug/app-debug.apk
